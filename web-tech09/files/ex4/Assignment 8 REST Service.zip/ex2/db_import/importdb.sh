#!/bin/bash
psql -U postgres -f createDB.sql